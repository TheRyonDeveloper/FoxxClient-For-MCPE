package com.foxxclient.app;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static final String MINECRAFT_PACKAGE =
            "com.mojang.minecraftpe";

    private final int ORANGE = Color.rgb(255, 87, 34);
    private final int BACKGROUND = Color.rgb(9, 13, 19);
    private final int CARD = Color.rgb(24, 32, 47);
    private final int TEXT = Color.rgb(241, 245, 249);
    private final int SECONDARY = Color.rgb(148, 163, 184);
    private final int GREEN = Color.rgb(0, 230, 118);
    private final int RED = Color.rgb(255, 82, 82);

    private TextView minecraftStatus;
    private Button launchButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        buildInterface();
        updateMinecraftStatus();
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (minecraftStatus != null) {
            updateMinecraftStatus();
        }
    }

    private void buildInterface() {

        ScrollView scrollView = new ScrollView(this);
        scrollView.setBackgroundColor(BACKGROUND);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 45, 28, 35);

        scrollView.addView(root);

        // Branding
        TextView logo = createText(
                "FOXXCLIENT",
                30,
                ORANGE
        );

        logo.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD
        );

        root.addView(logo);

        TextView version = createText(
                "Android Edition • API 27+",
                14,
                SECONDARY
        );

        root.addView(version);

        addSpace(root, 25);

        // Minecraft status card
        LinearLayout minecraftCard = createCard();

        TextView title = createText(
                "MINECRAFT BEDROCK",
                18,
                TEXT
        );

        title.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD
        );

        minecraftCard.addView(title);

        minecraftStatus = createText(
                "Checking Minecraft...",
                15,
                SECONDARY
        );

        minecraftCard.addView(minecraftStatus);

        launchButton = new Button(this);
        launchButton.setText("CHECKING...");
        launchButton.setTextColor(Color.WHITE);
        launchButton.setEnabled(false);

        LinearLayout.LayoutParams buttonParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        buttonParams.topMargin = 15;

        minecraftCard.addView(
                launchButton,
                buttonParams
        );

        root.addView(minecraftCard);

        addSpace(root, 20);

        // Modules
        TextView modulesTitle = createText(
                "CLIENT MODULES",
                18,
                TEXT
        );

        modulesTitle.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD
        );

        root.addView(modulesTitle);

        addModule(
                root,
                "FPS Display",
                "Performance • Coming next"
        );

        addModule(
                root,
                "Ping Display",
                "Network • Coming next"
        );

        addModule(
                root,
                "Keystrokes",
                "HUD • Coming next"
        );

        addModule(
                root,
                "Crosshair",
                "HUD • Coming next"
        );

        addSpace(root, 20);

        // Device information
        TextView deviceTitle = createText(
                "DEVICE",
                18,
                TEXT
        );

        deviceTitle.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD
        );

        root.addView(deviceTitle);

        LinearLayout deviceCard = createCard();

        deviceCard.addView(
                createText(
                        "Android 8.1+ compatible",
                        15,
                        TEXT
                )
        );

        deviceCard.addView(
                createText(
                        "FoxxClient v1.0",
                        14,
                        SECONDARY
                )
        );

        root.addView(deviceCard);

        setContentView(scrollView);
    }

    private void updateMinecraftStatus() {

        if (isMinecraftInstalled()) {

            minecraftStatus.setText(
                    "● Installed\n" +
                    "Package: " + MINECRAFT_PACKAGE
            );

            minecraftStatus.setTextColor(GREEN);

            launchButton.setText(
                    "LAUNCH MINECRAFT"
            );

            launchButton.setEnabled(true);

            launchButton.setOnClickListener(
                    new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            launchMinecraft();
                        }
                    }
            );

        } else {

            minecraftStatus.setText(
                    "● Minecraft Bedrock not detected"
            );

            minecraftStatus.setTextColor(RED);

            launchButton.setText(
                    "MINECRAFT NOT INSTALLED"
            );

            launchButton.setEnabled(false);
        }
    }

    private boolean isMinecraftInstalled() {

        PackageManager packageManager =
                getPackageManager();

        try {

            packageManager.getPackageInfo(
                    MINECRAFT_PACKAGE,
                    0
            );

            return true;

        } catch (PackageManager.NameNotFoundException e) {

            return false;
        }
    }

    private void launchMinecraft() {

        PackageManager packageManager =
                getPackageManager();

        Intent launchIntent =
                packageManager.getLaunchIntentForPackage(
                        MINECRAFT_PACKAGE
                );

        if (launchIntent != null) {

            launchIntent.addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK
            );

            try {

                startActivity(launchIntent);

            } catch (Exception e) {

                Toast.makeText(
                        this,
                        "Unable to launch Minecraft.",
                        Toast.LENGTH_LONG
                ).show();
            }

        } else {

            Toast.makeText(
                    this,
                    "Minecraft could not be launched.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    private LinearLayout createCard() {

        LinearLayout cardLayout =
                new LinearLayout(this);

        cardLayout.setOrientation(
                LinearLayout.VERTICAL
        );

        cardLayout.setPadding(
                22,
                20,
                22,
                20
        );

        cardLayout.setBackgroundColor(CARD);

        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        cardLayout.setLayoutParams(params);

        return cardLayout;
    }

    private TextView createText(
            String value,
            float size,
            int color
    ) {

        TextView view =
                new TextView(this);

        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setPadding(
                0,
                6,
                0,
                6
        );

        return view;
    }

    private void addModule(
            LinearLayout root,
            String name,
            String description
    ) {

        LinearLayout module =
                createCard();

        module.addView(
                createText(
                        name,
                        16,
                        TEXT
                )
        );

        module.addView(
                createText(
                        description,
                        13,
                        SECONDARY
                )
        );

        root.addView(module);

        addSpace(root, 8);
    }

    private void addSpace(
            LinearLayout root,
            int size
    ) {

        View space =
                new View(this);

        root.addView(
                space,
                new LinearLayout.LayoutParams(
                        1,
                        size
                )
        );
    }
}